from .constants import GRAY, WHITE, sq_size, GREY, CROWN
import pygame

class Piece:
    PADDING = 10
    OUTLINE = 3
    
    def calc_pos(self): # calculating position
        self.x = sq_size * self.col + sq_size // 2
        self.y = sq_size * self.row + sq_size // 2
        
    def __init__(self, row, col, color):
        self.row = row
        self.col = col
        self.color = color
        self.king = False
        self.x = 0
        self.y = 0
        self.calc_pos()

    def make_king(self): # making king if the piece reaches the last position on the other side
        self.king = True
    
    def draw(self, window): # drawing pieces and kings
        radius = sq_size//2 - self.PADDING
        pygame.draw.circle(window, GREY, (self.x, self.y), radius + self.OUTLINE)
        pygame.draw.circle(window, self.color, (self.x, self.y), radius)
        if self.king:
            window.blit(CROWN, (self.x - CROWN.get_Width()//2, self.y - CROWN.get_Height()//2))

    def move(self, row, col): # defining moves
        self.row = row
        self.col = col
        self.calc_pos()

    def __repr__(self):
        return str(self.color)