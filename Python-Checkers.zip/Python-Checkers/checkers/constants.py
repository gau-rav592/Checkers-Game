import pygame # will be used in main.py

Width, Height = 600, 600  #declating width and height of board
ROWS, COLS = 8, 8 # declaring rows and columns of the board
sq_size = Width//COLS # determining square size

# rgb colour codes
GRAY = (77, 77, 77)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (0, 0, 255)
GREY = (128,128,128)

CROWN = pygame.transform.scale(pygame.image.load('assets/crown.png'), (44, 25))  # crown image
