import pygame
from checkers.game import Game
from checkers.constants import Width, Height, sq_size, GRAY, WHITE
from minimax.algorithm import minimax

FPS = 60

WINDOW = pygame.display.set_mode((Width, Height)) # creating a window
pygame.display.set_caption('Checkers Game')

def get_row_col_from_mouse(pos): # for position
    x, y = pos
    row = y // sq_size
    col = x // sq_size
    return row, col

def main():
    run = True
    clock = pygame.time.Clock()
    game = Game(WINDOW)

    while run:
        clock.tick(FPS)
        
        if game.turn == WHITE:
            value, new_b = minimax(game.get_board(), 4, WHITE, game, float("-inf"), float("inf")) # algo
            game.move_ai(new_b)
        
        if game.winner() != None:
            print(game.winner())
            run = False
            
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                row, col = get_row_col_from_mouse(pos)
                game.select(row, col)

        game.update()
    
    pygame.quit()

main()